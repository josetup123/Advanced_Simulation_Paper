1. A2C and DQN use Python to solve the maintenance problem
2. The integrated ones combine Anylogic with Python to solve the TSP in the UT campus