#import pandas as pd
#import numpy as np
import os
from gurobipy import *
import warnings
import time

warnings.filterwarnings('ignore')

class test_attacker:
    # int, int, int, int, matrix[[], [], ...]
    def __init__(self, num_attacker, num_defender, Nodes, Edges, Capacities):
        self.Attacker = num_attacker
        self.Defender = num_defender
        self.Node = Nodes
        self.Edge = Edges
        self.Capacity = Capacities
        

    # list, list (length = Edges)
    def model(self, attacked_edges, defended_edges):
        node = self.Node
        # Create a new model
        m = Model("MIP")
        
        C = []
        count = 0
        for i in range(len(self.Capacity)):
            tmp = []
            for j in range(len(self.Capacity[i])):
                if (self.Capacity[i][j] == 0):
                    tmp.append(0)
                else:
                    if (attacked_edges[count] == 1 and defended_edges[count] == 0):
                        tmp.append(0)
                    else:
                        tmp.append(self.Capacity[i][j])
                    count += 1
            C.append(tmp)


        f = m.addVar(vtype=GRB.CONTINUOUS, name="f")

        x = m.addVars(node, node, vtype=GRB.CONTINUOUS, name="X")

        # Set objective
        m.setObjective(f, GRB.MAXIMIZE)
        m.Params.LogToConsole = 0

        tmp1 = 0
        tmp2 = 0
        for i in range(len(C)):
            for j in range(len(C[i])):
                if (i == 0):
                    tmp1 = tmp1 + x[i, j]
                if (j == node - 1):
                    tmp2 = tmp2 + x[i, j]
                m.addConstr(x[i, j] <= C[i][j])
                m.addConstr(x[i, j] >= 0)
        m.addConstr(tmp1 == f)
        m.addConstr(tmp2 == f)

        for i in range(1, len(C)-1):
            flow_in = 0
            flow_out = 0
            for j in range(len(C)):
                flow_in += x[j, i]
                flow_out += x[i, j]
            m.addConstr(flow_in == flow_out)

        m.optimize()

        res = 0
        try:
            '''
            for i in range(node):
                for j in range(node):
                    print(x[i,j].X, i, j)
            m.write("out.sol")
            '''
            res = m.ObjVal
        except:
            print('error')
        return res

if __name__ == "__main__":
    map_init = test_attacker(2, 3, 4, 5, [[0, 2, 3, 1], [0, 0, 0, 1], [0, 0, 0, 2], [0, 0, 0, 0]])
    a = map_init.model([1, 0, 1, 0, 0], [1, 1, 1, 0, 0])
    print(a)
