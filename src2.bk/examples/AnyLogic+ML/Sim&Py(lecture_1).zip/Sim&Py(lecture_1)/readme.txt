1. pypeline_demo shows the max-flow interdiction problem at the end of the slides
2. attacker.py creates the function of map initialization and model solver
3. DefenderAttacker.alp uses pypeline to import attacker.py to solve the max-flow under any certain situation
4. Check the path of pypeline and python