#import pandas as pd
#import numpy as np
import os
from gurobipy import *
import warnings
import time

warnings.filterwarnings('ignore')

class test:
    # int, int, int, int, matrix[[], [], ...]
    def __init__(self, Nodes, Edges, Capacities):
        self.Node = Nodes
        self.Edge = Edges
        self.Capacity = Capacities
        

    # list, list (length = Edges)
    def model(self):
        node = self.Node
        C = self.Capacity
        
        # Create a new model
        m = Model("MIP")

        f = m.addVar(vtype=GRB.CONTINUOUS, name="f")

        x = m.addVars(node, node, vtype=GRB.CONTINUOUS, name="X")

        # Set objective
        m.setObjective(f, GRB.MAXIMIZE)
        m.Params.LogToConsole = 0

        tmp1 = 0
        tmp2 = 0
        for i in range(len(C)):
            for j in range(len(C[i])):
                if (i == 0):
                    tmp1 = tmp1 + x[i, j]
                if (j == node - 1):
                    tmp2 = tmp2 + x[i, j]
                m.addConstr(x[i, j] <= C[i][j])
                m.addConstr(x[i, j] >= 0)
        m.addConstr(tmp1 == f)
        m.addConstr(tmp2 == f)

        for i in range(1, len(C)-1):
            flow_in = 0
            flow_out = 0
            for j in range(len(C)):
                flow_in += x[j, i]
                flow_out += x[i, j]
            m.addConstr(flow_in == flow_out)

        m.optimize()

        res = 0
        try:
            res = m.ObjVal
        except:
            print('error')
        return res

if __name__ == "__main__":
    map_init = test(4, 5, [[0, 2, 3, 1], [0, 0, 0, 1], [0, 0, 0, 2], [0, 0, 0, 0]])
    a = map_init.model()
    print(a)
